package InaDestiaYuliana;

public class kriptografi {
    public static void main(String[] args) {
        kriptografForm n = new kriptografForm();
        n.setVisible(true);
    }
}
